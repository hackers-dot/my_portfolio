export async function POST(req: Request) {
  // Simulate processing with minimal validation; no storage by default.
  try {
    const body = await req.json()
    if (!body?.name || !body?.email || !body?.message) {
      return Response.json({ success: false }, { status: 400 })
    }
    // Simulate async email send
    await new Promise((r) => setTimeout(r, 800))
    return Response.json({ success: true })
  } catch {
    return Response.json({ success: false }, { status: 500 })
  }
}
