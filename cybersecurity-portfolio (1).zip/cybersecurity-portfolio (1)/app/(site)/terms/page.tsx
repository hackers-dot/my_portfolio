import { GlassCard } from "@/components/glass-card"

export default function TermsPage() {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Terms of Service</h1>
        <p className="mt-2 text-white/80">
          The rules and conditions for using this website and the content presented here.
        </p>
      </header>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Using the site</h2>
        <p className="text-white/80">
          You agree not to misuse this site, disrupt its operation, or attempt unauthorized access. Educational content
          must be used responsibly and lawfully.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Intellectual property</h2>
        <p className="text-white/80">
          Unless otherwise stated, content belongs to the author. You may reference material with proper attribution and
          links. Do not reproduce significant portions without permission.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">No guarantees</h2>
        <p className="text-white/80">
          Content is provided “as is.” There is no guarantee of accuracy, completeness, or fitness for a particular
          purpose. Use at your own risk.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Links to third parties</h2>
        <p className="text-white/80">
          External links are provided for convenience. We are not responsible for their content or policies.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Changes</h2>
        <p className="text-white/80">
          These terms may be updated over time. Continued use of the site after changes constitutes acceptance of the
          updated terms.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Contact</h2>
        <p className="text-white/80">Questions about these terms? Email: iaminfinite03@gmail.com</p>
      </GlassCard>
    </div>
  )
}
