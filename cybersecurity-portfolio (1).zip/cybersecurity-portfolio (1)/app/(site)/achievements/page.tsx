import { GlassCard } from "@/components/glass-card"

const items = [
  {
    title: "IIT Dharwad — VeniVidiVici 2.0 (Parsec 5.0)",
    detail:
      "Certificate of Participation. Networking with innovators and technologists; enriching experience and learning.",
  },
  {
    title: "Bypass CTF — Solutions 2k25 (AIT Pune)",
    detail:
      "Participated as Team Debians; improved problem-solving, applied cybersecurity concepts, and collaborated under pressure.",
  },
  {
    title: "Astra Lab1 Pentesting Simulation",
    detail:
      "Captured 5 flags using Metasploit, hidden file discovery, and MySQL password cracking; strengthened exploitation skills.",
  },
  {
    title: "METACTF (United States)",
    detail: "Scored 88.53% among 2,692 teams in a 4-hour CTF; reinforced time-bound problem solving and persistence.",
  },
  {
    title: "Octopyder Certified Ethical Hacker — Foundation & Intermediate",
    detail:
      "Completed training; covered cybersecurity principles, attack techniques (DDoS, phishing, password cracking), Burp-based assessments, and countermeasures.",
  },
  {
    title: "IndiaAI CyberGuard AI Hackathon",
    detail:
      "Team Octopyder: NLP model to help citizens file cybercrime reports (NCRP). Implemented Logistic Regression, LSTM, BERT; achieved F1-score 0.96.",
  },
  {
    title: "Parrot OS Payload Exercise",
    detail:
      "Built a payload in a controlled virtual environment to gain access on a Windows 10 machine for ethical testing and mitigation learning.",
  },
  {
    title: "MS08-067 Vulnerability Research",
    detail: "Performed Windows XP RCE lab; emphasized patching and secure configurations for legacy systems.",
  },
  {
    title: "Startup Mela — ICI CET Student Chapter FEST'24",
    detail:
      "Team Octopyder won 1st place; presented startup work and gained valuable feedback. Walked away with new gadgets!",
  },
  {
    title: "Secure Web App on Localhost",
    detail:
      "Built a local web app backed by SQL; implemented HTTPS (in lab) and secure input handling for safer interactions.",
  },
  {
    title: "Instagram Phishing Page (Ethical, Lab)",
    detail:
      "Simulated credential capture and safe redirect to real Instagram login to raise awareness—strictly for lab education.",
  },
]

export default function AchievementsPage() {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Certifications & Achievements</h1>
        <p className="mt-2 text-white/80">Hackathons, CTFs, training, and milestones.</p>
      </header>
      <div className="grid gap-6 md:grid-cols-2">
        {items.map((item) => (
          <GlassCard key={item.title} className="p-6">
            <h3 className="text-lg font-semibold">{item.title}</h3>
            <p className="mt-2 text-white/80">{item.detail}</p>
          </GlassCard>
        ))}
      </div>
    </div>
  )
}
