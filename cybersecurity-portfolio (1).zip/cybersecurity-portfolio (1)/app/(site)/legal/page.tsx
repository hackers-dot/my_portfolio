import { GlassCard } from "@/components/glass-card"

export default function LegalPage() {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Legal</h1>
        <p className="mt-2 text-white/80">
          Information about this website, acceptable use, and responsible security research guidelines.
        </p>
      </header>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Purpose of this site</h2>
        <p className="text-white/80">
          This portfolio showcases educational cybersecurity work conducted in isolated lab environments or with
          explicit authorization. Nothing on this site constitutes encouragement to perform unauthorized testing.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Acceptable use</h2>
        <ul className="list-disc space-y-2 pl-5 text-white/80">
          <li>Do not attempt to exploit, attack, or scrape this website or its infrastructure.</li>
          <li>
            Any code, write-ups, or methods are for educational purposes only. Use them responsibly and lawfully with
            proper permissions.
          </li>
          <li>Respect intellectual property, privacy, and applicable laws in your jurisdiction.</li>
        </ul>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Ethical security</h2>
        <p className="text-white/80">
          All offensive techniques referenced are practiced within virtual labs or controlled environments. Do not use
          them against systems you do not own or operate without explicit written permission.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">No warranties</h2>
        <p className="text-white/80">
          Content is provided “as is” without warranties. While care is taken to keep information accurate and current,
          errors may occur. Use at your own risk.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-4">
        <h2 className="text-xl font-semibold">Contact</h2>
        <p className="text-white/80">For questions, contact: iaminfinite03@gmail.com</p>
      </GlassCard>
    </div>
  )
}
