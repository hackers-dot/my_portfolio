import { GlassCard } from "@/components/glass-card"

export default function BlogPage() {
  const posts = [
    {
      title: "Building a Custom SIEM: From Rules to Anomaly Detection",
      excerpt: "Marrying signatures with ML for real-time visibility and cleaner alerts.",
    },
    {
      title: "Detecting Brute-Force: Lockouts, Throttling, and SIEM Correlation",
      excerpt: "Balancing security and usability while reducing false positives.",
    },
    {
      title: "Lessons from Astra Lab1 and MS08-067",
      excerpt: "Exploitation flow, patching, and safe lab practices.",
    },
  ]
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Write-ups</h1>
        <p className="mt-2 text-white/80">Notes from labs, research, and field work.</p>
      </header>
      <div className="grid gap-6 md:grid-cols-2">
        {posts.map((p) => (
          <GlassCard key={p.title} className="p-6">
            <h3 className="text-xl font-semibold">{p.title}</h3>
            <p className="mt-2 text-white/80">{p.excerpt}</p>
          </GlassCard>
        ))}
      </div>
    </div>
  )
}
