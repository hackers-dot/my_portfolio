"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { GlassCard } from "@/components/glass-card"
import { useToast } from "@/hooks/use-toast"

export default function ContactPage() {
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ name: "", email: "", message: "", honey: "" })

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (form.honey) return // bot
    setLoading(true)
    try {
      const res = await fetch("/actions/contact", {
        method: "POST",
        body: JSON.stringify({ name: form.name, email: form.email, message: form.message }),
      })
      const data = await res.json()
      if (data.success) {
        toast({ title: "Message sent", description: "Thanks for reaching out!" })
        setForm({ name: "", email: "", message: "", honey: "" })
      } else {
        toast({ title: "Something went wrong", description: "Please try again later." })
      }
    } catch {
      toast({ title: "Network error", description: "Please try again." })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-10">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Contact</h1>
        <p className="mt-2 text-white/80">Reach me via Gmail or LinkedIn—or send a message.</p>
      </header>

      <div className="grid gap-6 md:grid-cols-2">
        <GlassCard className="p-6">
          <h3 className="text-xl font-semibold">Direct</h3>
          <div className="mt-4 space-y-3">
            <a
              className="inline-flex items-center gap-2 rounded-md border border-white/15 bg-white/5 px-4 py-2 text-white/90 hover:bg-white/10"
              href="mailto:iaminfinite03@gmail.com"
            >
              Gmail: iaminfinite03@gmail.com
            </a>
            <a
              className="inline-flex items-center gap-2 rounded-md border border-white/15 bg-white/5 px-4 py-2 text-white/90 hover:bg-white/10"
              href="https://www.linkedin.com/in/anant-kumar-9a2923319/"
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn profile (opens in a new tab)"
            >
              LinkedIn: /in/anant-kumar-9a2923319/
            </a>
          </div>
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="text-xl font-semibold">Send a message</h3>
          <form onSubmit={submit} className="mt-4 space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  required
                />
              </div>
            </div>
            <div className="sr-only">
              <Label htmlFor="company">Company</Label>
              <Input id="company" value={form.honey} onChange={(e) => setForm({ ...form, honey: e.target.value })} />
            </div>
            <div>
              <Label htmlFor="message">Message</Label>
              <Textarea
                id="message"
                rows={5}
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                required
              />
            </div>
            <Button type="submit" disabled={loading} className="neon-btn-primary">
              {loading ? "Sending…" : "Send"}
            </Button>
          </form>
        </GlassCard>
      </div>
    </div>
  )
}
