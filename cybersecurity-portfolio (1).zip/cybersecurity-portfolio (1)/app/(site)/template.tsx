"use client"

import type { PropsWithChildren } from "react"
import { WithNeon } from "@/components/with-neon"

// This template mounts neon styles for this segment.
export default function Template({ children }: PropsWithChildren) {
  return (
    <>
      <WithNeon />
      {children}
    </>
  )
}
