export default function Loading() {
  return <div className="grid min-h-[40vh] place-items-center text-white/80">Loading…</div>
}
