import { GlassCard } from "@/components/glass-card"

export default function AboutPage() {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">About</h1>
        <p className="mt-2 text-white/80">
          Cybersecurity Enthusiast | Penetration Tester | Ethical Hacking | Threat Analysis | Red Teaming
        </p>
      </header>
      <GlassCard className="p-6 space-y-4">
        <p className="text-white/90">
          I am a cybersecurity student with a deep passion for ethical hacking, penetration testing, and network
          security. Currently, I’m interning as a Penetration Tester at Octopyder Services, identifying vulnerabilities,
          conducting assessments, and applying offensive security techniques to strengthen defenses.
        </p>
        <p className="text-white/80">
          Hands-on with IDS/IPS, web security, and threat analysis, I work with Kali Linux, Parrot OS, Metasploit,
          Wireshark, Scapy, SQL injection testing, and automation using Python. I actively develop and test IDS that
          monitor real-time simulations—SSH brute force, DoS/DDoS, SMTP/POP3 exploits, and network intrusion attempts. I
          also research social engineering tactics, fake follower detection, and security automation.
        </p>
        <p className="text-white/80">
          Beyond labs, I participate in hackathons and CTFs to sharpen offensive skills. I’m eager to contribute to
          cybersecurity research, penetration testing projects, and automation innovations—learning and collaborating
          with like-minded professionals along the way.
        </p>
      </GlassCard>
      <GlassCard className="p-6">
        <h3 className="text-xl font-semibold">Contact</h3>
        <p className="mt-2 text-white/80">Anant Kumar · B.Tech CSE · Email: iaminfinite03@gmail.com</p>
      </GlassCard>
    </div>
  )
}
