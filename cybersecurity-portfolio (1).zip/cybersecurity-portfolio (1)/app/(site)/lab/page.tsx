import { GlassCard } from "@/components/glass-card"

export default function LabPage() {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">My Lab</h1>
        <p className="mt-2 text-white/80">Kali & Parrot environments · IDS/IPS · Router/Firewall · SIEM/Logging</p>
      </header>

      <GlassCard className="p-6">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-3">
            <h3 className="text-xl font-semibold">Topology</h3>
            <ul className="list-disc pl-5 text-white/80">
              <li>Attacker VM (Kali/Parrot with Metasploit, Nmap, Burp, ZAP)</li>
              <li>Target VM (web services, databases)</li>
              <li>IDS/IPS (Suricata/Snort)</li>
              <li>Router/Firewall (policy rules, rate limit testing)</li>
              <li>Logging/SIEM node (dashboards, anomaly detection)</li>
            </ul>
            <p className="text-sm text-white/70">
              All experiments are in isolated environments or with explicit permission. Strict ethical guidelines apply.
            </p>
          </div>
          <div className="relative">
            <div className="aspect-[4/3] rounded-xl border border-white/10 bg-white/5 p-6 backdrop-blur">
              <div className="relative h-full w-full overflow-hidden rounded-lg border border-white/10 bg-gradient-to-tr from-fuchsia-500/10 via-cyan-400/10 to-violet-500/10">
                {/* Lane path (visual) */}
                <svg className="absolute inset-0" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                  <defs>
                    <linearGradient id="laneGradLab" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="rgba(230,66,248,.6)" />
                      <stop offset="50%" stopColor="rgba(122,94,255,.6)" />
                      <stop offset="100%" stopColor="rgba(0,229,255,.6)" />
                    </linearGradient>
                  </defs>
                  {/* closed loop path */}
                  <path
                    d="M 12 50 L 35 20 L 68 20 L 85 60 L 40 80 Z"
                    stroke="url(#laneGradLab)"
                    strokeWidth="0.8"
                    fill="none"
                    opacity="0.7"
                  />
                </svg>

                {/* Packets moving along the path */}
                {Array.from({ length: 10 }).map((_, i) => (
                  <span key={i} className="lab-packet" style={{ animationDelay: `${i * 0.5}s` }} />
                ))}

                {/* Nodes */}
                <div className="lab-node" style={{ left: "12%", top: "50%" }}>
                  <div className="lab-node-halo" />
                  <div className="lab-node-chip">Attacker VM</div>
                  <div className="lab-node-sub">Kali/Parrot · Metasploit · Nmap · Burp · ZAP</div>
                </div>

                <div className="lab-node" style={{ left: "35%", top: "20%" }}>
                  <div className="lab-node-halo" />
                  <div className="lab-node-chip">Router/Firewall</div>
                  <div className="lab-node-sub">Policies · NAT · Rate limits</div>
                </div>

                <div className="lab-node" style={{ left: "68%", top: "20%" }}>
                  <div className="lab-node-halo" />
                  <div className="lab-node-chip">IDS/IPS</div>
                  <div className="lab-node-sub">Suricata · Snort</div>
                </div>

                <div className="lab-node" style={{ left: "85%", top: "60%" }}>
                  <div className="lab-node-halo" />
                  <div className="lab-node-chip">Target VM</div>
                  <div className="lab-node-sub">Web services · Databases</div>
                </div>

                <div className="lab-node" style={{ left: "40%", top: "80%" }}>
                  <div className="lab-node-halo" />
                  <div className="lab-node-chip">Logging/SIEM</div>
                  <div className="lab-node-sub">Dashboards · Anomaly detection</div>
                </div>

                {/* Arrival ripple near SIEM to imply ingest */}
                <div className="lab-arrival-ripple" style={{ left: "40%", top: "80%" }} />
                <div className="lab-arrival-ripple delay-200" style={{ left: "40%", top: "80%" }} />

                {/* Scanline and subtle grid */}
                <div className="pointer-events-none absolute inset-0 lab-scan" />
                <div className="pointer-events-none absolute inset-0 lab-grid" />
              </div>
            </div>
          </div>
        </div>
      </GlassCard>

      <GlassCard className="p-6">
        <h3 className="text-xl font-semibold">Simulations</h3>
        <ul className="mt-3 grid gap-2 text-white/80 md:grid-cols-2">
          <li>DoS/DDoS mitigation drills (WAF + edge rate limits)</li>
          <li>SSH brute force detection (lockout thresholds + correlation)</li>
          <li>SQL injection testing and hardening</li>
          <li>SMTP/POP3 exploit monitoring</li>
          <li>Packet capture workflows (Wireshark, Scapy)</li>
        </ul>
      </GlassCard>

      {/* Local CSS for the simulation */}
      <style
        dangerouslySetInnerHTML={{
          __html: `
          .lab-grid {
            background-image: linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
                             linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px);
            background-size: 24px 24px, 24px 24px;
            mix-blend-mode: screen;
          }

          .lab-scan {
            background: linear-gradient(180deg, transparent 0%, rgba(255,255,255,0.06) 50%, transparent 100%);
            background-size: 100% 40px;
            animation: labScan 6s linear infinite;
          }
          @keyframes labScan { 0% { background-position-y: -40px } 100% { background-position-y: 140% } }

          .lab-packet {
            position: absolute;
            top: 0; left: 0;
            width: 10px; height: 10px; border-radius: 9999px;
            background: radial-gradient(circle at 30% 30%, #00E5FF, #7A5EFF);
            box-shadow: 0 0 16px rgba(0,229,255,0.55), 0 0 24px rgba(122,94,255,0.45);
            opacity: .18;
            offset-path: path('M 12 50 L 35 20 L 68 20 L 85 60 L 40 80 Z');
            offset-distance: 0%;
            offset-rotate: 0deg;
            animation: labFlow 5.6s linear infinite;
          }
          @keyframes labFlow { 0% { offset-distance: 0%; opacity: .2 } 10% { opacity: 1 } 100% { offset-distance: 100%; opacity: .2 } }

          .lab-node { position: absolute; transform: translate(-50%, -50%); text-align: center; }
          .lab-node-chip {
            display: inline-block; padding: 6px 10px; border-radius: 12px; font-size: 12px; color: #fff;
            background: rgba(255,255,255,.10); border: 1px solid rgba(255,255,255,.18); backdrop-filter: blur(6px);
            box-shadow: 0 0 18px rgba(122,94,255,.35), inset 0 0 8px rgba(0,229,255,.18);
          }
          .lab-node-sub { margin-top: 6px; font-size: 11px; color: rgba(255,255,255,.85); opacity: .85; }

          .lab-node-halo::before, .lab-node-halo::after {
            content: ''; position: absolute; inset: -22px; border-radius: 9999px;
            background: radial-gradient(circle, rgba(122,94,255,.35), transparent 60%); filter: blur(8px);
            animation: haloPulse 2.6s ease-in-out infinite;
          }
          .lab-node-halo::after { inset: -30px; background: radial-gradient(circle, rgba(0,229,255,.25), transparent 70%); animation-duration: 3.2s; }
          @keyframes haloPulse { 0%,100% { opacity: .55 } 50% { opacity: 1 } }

          .lab-arrival-ripple {
            position: absolute; width: 8px; height: 8px; transform: translate(-50%, -50%); border-radius: 9999px;
            box-shadow: 0 0 0 0 rgba(0,229,255,.5); animation: ripple 2.8s ease-out infinite;
          }
          .lab-arrival-ripple.delay-200 { animation-delay: .2s; }
          @keyframes ripple { 0% { box-shadow: 0 0 0 0 rgba(0,229,255,.5); opacity: 1 } 100% { box-shadow: 0 0 0 28px rgba(0,229,255,0); opacity: 0 } }
        `,
        }}
      />
    </div>
  )
}
