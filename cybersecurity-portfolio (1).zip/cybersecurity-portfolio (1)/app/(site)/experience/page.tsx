import { GlassCard } from "@/components/glass-card"

export default function ExperiencePage() {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Experience</h1>
        <p className="mt-2 text-white/80">SOC operations, SIEM development, penetration testing, incident response.</p>
      </header>

      <GlassCard className="p-6 space-y-4">
        <h3 className="text-xl font-semibold">
          SOC Analyst & Penetration Tester Intern — Octopyder Services Pvt. Ltd.
        </h3>
        <p className="text-white/70">Feb 2025 – May 2025 · On-site · Jaipur, Rajasthan</p>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-white/85">
          <li>
            Developed and deployed a custom SIEM tool combining ML-based anomaly detection with signature rules for
            real-time monitoring.
          </li>
          <li>Performed penetration testing and vulnerability assessments on web applications and internal systems.</li>
          <li>Analyzed logs from firewalls, IDS/IPS, and web servers to detect suspicious activities and incidents.</li>
          <li>
            Created SIEM monitoring rules and dashboards to track anomalies, policy violations, and threat patterns.
          </li>
        </ul>
      </GlassCard>

      <GlassCard className="p-6">
        <h3 className="text-xl font-semibold">Education</h3>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-white/85">
          <li>
            Vivekananda Global University, Jaipur — B.Tech in Computer Science & Engineering (Jun 2022 – Present), CGPA:
            7.00
          </li>
          <li>SKR College, Barbigha, Bihar — Higher Secondary Education (Science, BSEB), 65.8%</li>
        </ul>
      </GlassCard>
    </div>
  )
}
