import { GlassCard } from "@/components/glass-card"
import { Badge } from "@/components/ui/badge"

export default function SkillsPage() {
  const categories = [
    {
      name: "Core Security",
      skills: [
        "Penetration Testing",
        "Vulnerability Assessment",
        "Threat Intelligence",
        "Incident Response",
        "Log/Traffic Analysis",
        "IDS/IPS Tuning",
        "SIEM Rules & Dashboards",
      ],
    },
    {
      name: "Offensive Labs",
      skills: ["Brute Force (lab only)", "DoS/DDoS Simulation", "Web Security", "SQL Injection Testing", "CTFs"],
    },
    {
      name: "Operating Systems",
      skills: ["Windows", "Linux", "Kali Linux", "Parrot OS"],
    },
    {
      name: "Languages & Databases",
      skills: ["Python", "C++", "Shell Script", "SQL", "MySQL", "MongoDB"],
    },
    {
      name: "Tools",
      skills: [
        "Metasploit",
        "Wireshark",
        "Scapy",
        "Burp Suite",
        "OWASP ZAP",
        "Nmap",
        "Suricata",
        "Snort",
        "Docker",
        "VirtualBox/VMware",
        "Git/GitHub",
        "VS Code",
      ],
    },
    {
      name: "Soft Skills & Coursework",
      skills: ["Teamwork", "Problem-solving", "Communication", "Critical Thinking", "DSA", "DBMS"],
    },
    {
      name: "Interests",
      skills: ["Malware Detection", "Threat Analysis", "Incident Handling", "DevOps"],
    },
  ]

  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Skills</h1>
        <p className="mt-2 text-white/80">Hands-on expertise, tools, and interests.</p>
      </header>

      <div className="grid gap-6 md:grid-cols-2">
        {categories.map((cat, idx) => (
          <GlassCard key={idx} className="p-6">
            <h3 className="text-xl font-semibold">{cat.name}</h3>
            <div className="mt-4 flex flex-wrap gap-2">
              {cat.skills.map((s) => (
                <Badge key={s} variant="outline" className="border-white/20 bg-white/5 text-white/90">
                  {s}
                </Badge>
              ))}
            </div>
          </GlassCard>
        ))}
      </div>
    </div>
  )
}
