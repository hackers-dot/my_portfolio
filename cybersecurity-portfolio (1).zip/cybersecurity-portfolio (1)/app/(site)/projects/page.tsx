import { ProjectCard } from "@/components/project-card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ProjectsPage() {
  const labs = [
    {
      title: "Custom SIEM for Real-Time Monitoring",
      summary:
        "Combined ML-based anomaly detection with signature rules; dashboards and alerting for real-time threats.",
      highlights: ["SIEM rules", "Anomaly detection", "Dashboards"],
      stack: ["Python", "Elastic", "Regex/Signatures"],
    },
    {
      title: "DDoS & Brute Force Simulation Lab",
      summary: "Isolated lab to evaluate rate limits, WAF rules, and IDS alerts for DoS/DDoS and brute-force attempts.",
      highlights: ["Rate limiting", "WAF", "Suricata/Snort"],
      stack: ["Kali", "Parrot", "Tcpreplay", "Suricata"],
    },
    {
      title: "Astra Lab1 Pentesting",
      summary:
        "Pentest simulation capturing 5 flags via Metasploit, hidden file discovery, and MySQL password cracking.",
      highlights: ["Metasploit", "Privilege paths", "Password cracking"],
      stack: ["Kali", "Metasploit", "MySQL"],
    },
    {
      title: "MS08-067 Research",
      summary:
        "Hands-on RCE exploration on Windows XP; reinforced patch management, exploitation flow and mitigations.",
      highlights: ["Exploit dev basics", "Patch importance", "RCE chain"],
      stack: ["Metasploit", "Windows XP"],
    },
  ]

  const webApps = [
    {
      title: "Real-Time Keylogger & Monitoring Tool",
      summary:
        "Python-based keylogger on Kali; secure log transmission every 5s, automated screenshots, live web dashboard.",
      highlights: ["Secure transport", "Low overhead", "Continuous operation"],
      stack: ["Python", "Flask", "Kali"],
    },
    {
      title: "Localhost Web App with SQL Backend",
      summary:
        "Hardened local web app with SQL backend; implementing HTTPS and input validation for safer interactions.",
      highlights: ["SQL hardening", "HTTPS setup (lab)", "Input validation"],
      stack: ["PHP", "SQL", "HTML"],
    },
  ]

  const research = [
    {
      title: "NCRP Cybercrime NLP",
      summary:
        "NLP classification pipeline (LogReg, LSTM, BERT) for citizen reports; achieved F1-score 0.96 in hackathon.",
      highlights: ["Text preprocessing", "Modeling", "Evaluation"],
      stack: ["Python", "BERT", "LSTM"],
    },
    {
      title: "Instagram Phishing Simulation (Ethical, Lab)",
      summary: "Simulated phishing page integrated with local server to study credential capture and safe redirection.",
      highlights: ["Awareness", "Blue-team insights", "Controlled lab"],
      stack: ["HTML", "PHP", "Localhost"],
    },
  ]

  return (
    <div className="space-y-10">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Projects</h1>
        <p className="mt-2 text-white/80">Security labs, web apps, and research.</p>
      </header>

      <Tabs defaultValue="labs" className="space-y-6">
        <TabsList className="bg-white/10 backdrop-blur">
          <TabsTrigger value="labs">Security Labs</TabsTrigger>
          <TabsTrigger value="web">Web Apps</TabsTrigger>
          <TabsTrigger value="research">Research</TabsTrigger>
        </TabsList>
        <TabsContent value="labs" className="grid gap-6 md:grid-cols-2">
          {labs.map((p, i) => (
            <ProjectCard key={i} {...p} />
          ))}
        </TabsContent>
        <TabsContent value="web" className="grid gap-6 md:grid-cols-2">
          {webApps.map((p, i) => (
            <ProjectCard key={i} {...p} />
          ))}
        </TabsContent>
        <TabsContent value="research" className="grid gap-6 md:grid-cols-2">
          {research.map((p, i) => (
            <ProjectCard key={i} {...p} />
          ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}
