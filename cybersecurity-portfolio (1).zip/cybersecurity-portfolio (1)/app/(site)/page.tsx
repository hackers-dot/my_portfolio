import { Button } from "@/components/ui/button"
import { GlassCard } from "@/components/glass-card"
import { FeatureStrip } from "@/components/feature-strip"
import { HowItWorks } from "@/components/how-it-works"
import { ProvidersScatter } from "@/components/providers-scatter"
import { ScenarioExplorer } from "@/components/scenario-explorer"
import { FAQ } from "@/components/faq"
import Link from "next/link"
import { Shield, Send, Rocket, Terminal } from "lucide-react"

export default function HomePage() {
  return (
    <div className="space-y-24">
      {/* Hero */}
      <section className="relative">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div className="space-y-6">
            <p className="text-sm uppercase tracking-wider text-cyan-300/90">
              Cybersecurity Enthusiast · Cyber Security student
            </p>
            <h1 className="text-balance text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl">Anant Kumar</h1>
            <p className="text-pretty text-lg/7 text-white/80">
              I identify vulnerabilities, run safe offensive simulations in lab environments, and build/automate
              defenses with Python, SIEM rules, and IDS/IPS tuning.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/projects">
                <Button size="lg" className="neon-btn-primary">
                  <Rocket className="mr-2 h-4 w-4" /> View Projects
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline" className="neon-btn-outline bg-transparent">
                  <Send className="mr-2 h-4 w-4" /> Contact Me
                </Button>
              </Link>
            </div>
            <div className="flex flex-wrap gap-6 pt-4 text-sm text-white/75">
              <div className="inline-flex items-center gap-2">
                <Shield className="h-4 w-4 text-cyan-300" />
                IDS/IPS, SIEM, DoS/DDoS, Brute Force (lab only)
              </div>
              <div className="inline-flex items-center gap-2">
                <Terminal className="h-4 w-4 text-violet-300" />
                Kali · Parrot · Metasploit · Wireshark · Burp
              </div>
            </div>
          </div>
          {/* Hero visual glass block */}
          <div className="relative">
            <GlassCard className="p-6 md:p-8 aspect-[4/3]">
              <div className="relative h-full w-full">
                {/* CYBERPUNK GLITCH + HACKING SIM OVERLAY */}
                <div className="pointer-events-none absolute inset-0">
                  {/* Glitch banner */}
                  <div className="glitch-banner" aria-hidden="true">
                    <span className="glitch" data-text="CYBER//GLITCH">
                      CYBER//GLITCH
                    </span>
                  </div>

                  {/* Pulse rings */}
                  <div className="pulse-ring" />
                  <div className="pulse-ring delay-300" />

                  {/* Horizontal hacking ticker (infinite loop) */}
                  <div className="hack-ticker" aria-hidden="true">
                    <div className="hack-track">
                      {
                        "> INIT handshake… | SCAN ports: 22,80,443 | WAF: active | IDS: Suricata | SIEM: ingest OK | STATUS: MONITOR | HASH check: OK | AES-256 session: up | "
                      }
                    </div>
                    <div className="hack-track hack-track--dup">
                      {
                        "> INIT handshake… | SCAN ports: 22,80,443 | WAF: active | IDS: Suricata | SIEM: ingest OK | STATUS: MONITOR | HASH check: OK | AES-256 session: up | "
                      }
                    </div>
                  </div>

                  {/* Subtle noise/flicker */}
                  <div className="glitch-noise" />
                </div>

                <div className="absolute inset-0 rounded-xl bg-gradient-to-tr from-fuchsia-500/20 via-cyan-400/10 to-violet-500/20 blur-2xl" />
                <div className="absolute inset-0 grid place-items-center">
                  {/* Background: lab simulation code rain */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 -z-10 overflow-hidden rounded-xl [mask-image:linear-gradient(to_bottom,transparent,rgba(0,0,0,0.6)_15%,rgba(0,0,0,0.8)_85%,transparent)]"
                  >
                    <div className="relative h-[200%] w-full">
                      <pre className="code-stream">
                        {`[LAB] INIT attack-sim module="ddos_surge" target=10.0.0.5 iface=eth1 rate=10kpps
[LAB] SYN flood warmup… window=128 burst=4 jitter=±2
[IDS] Suricata alert sid=220001 rev=1 proto=TCP evt="ET DOS Possible SYN Flood" src=10.0.0.10 dst=10.0.0.5
[SIEM] rule=anomaly.ddos_surge severity=HIGH corr=3 sources action=notify+dashboard
[LAB] TRACE flow_id=0xA17C rate=9864pps dropped=2% cpu=21%
[LOG] Nginx upstream 429s=64 route=/login ip=10.0.0.55 user=-
[LAB] Hydra auth spray userlist=200 delay=150ms lockout=enabled
[IDS] Brute-force candidate user="admin" failures=7 lockout-threshold=10
[SIEM] corr: ssh.failed_logins + geo.anomaly score=0.81 tag=BLUETEAM-INVESTIGATE
[PCAP] write file=/var/lab/pcap/2025-08-ssh-ddos.pcap size=12.4MB
[LAB] Tcpreplay run profile="burst-3" iface=eth2 speed=10Mbps
[IDS] HTTP SQLi probe payload="or 1=1--" id=ET-WEB-SQLI level=MED
[LAB] WAF rule set=app-protect id=900120 action=block
[SIEM] dash: DDoS panel updated | p95 latency=138ms | error_rate=0.9%
[LAB] Scapy SYN seq=0x1F3A ack=0x00 win=64240 mss=1460 sack=on ts=now
[IDS] Threshold cooled down below limit; status transitioning -> WATCH
[LAB] Cleanup: reset iptables & tc; export artifacts=pcap,alerts,siem.json
[REPORT] Summary: attacks=2 alerts=12 FP=1 mitigations=rate-limit,waf,lockout
[NOTE] All experiments executed in isolated lab. Do not test on live systems.`}
                      </pre>
                      {/* Duplicate stream for seamless scroll */}
                      <pre className="code-stream code-stream--dup">
                        {`[LAB] INIT attack-sim module="ddos_surge" target=10.0.0.5 iface=eth1 rate=10kpps
[LAB] SYN flood warmup… window=128 burst=4 jitter=±2
[IDS] Suricata alert sid=220001 rev=1 proto=TCP evt="ET DOS Possible SYN Flood" src=10.0.0.10 dst=10.0.0.5
[SIEM] rule=anomaly.ddos_surge severity=HIGH corr=3 sources action=notify+dashboard
[LAB] TRACE flow_id=0xA17C rate=9864pps dropped=2% cpu=21%
[LOG] Nginx upstream 429s=64 route=/login ip=10.0.0.55 user=-
[LAB] Hydra auth spray userlist=200 delay=150ms lockout=enabled
[IDS] Brute-force candidate user="admin" failures=7 lockout-threshold=10
[SIEM] corr: ssh.failed_logins + geo.anomaly score=0.81 tag=BLUETEAM-INVESTIGATE
[PCAP] write file=/var/lab/pcap/2025-08-ssh-ddos.pcap size=12.4MB
[LAB] Tcpreplay run profile="burst-3" iface=eth2 speed=10Mbps
[IDS] HTTP SQLi probe payload="or 1=1--" id=ET-WEB-SQLI level=MED
[LAB] WAF rule set=app-protect id=900120 action=block
[SIEM] dash: DDoS panel updated | p95 latency=138ms | error_rate=0.9%
[LAB] Scapy SYN seq=0x1F3A ack=0x00 win=64240 mss=1460 sack=on ts=now
[IDS] Threshold cooled down below limit; status transitioning -> WATCH
[LAB] Cleanup: reset iptables & tc; export artifacts=pcap,alerts,siem.json
[REPORT] Summary: attacks=2 alerts=12 FP=1 mitigations=rate-limit,waf,lockout
[NOTE] All experiments executed in isolated lab. Do not test on live systems.`}
                      </pre>
                    </div>
                  </div>

                  {/* Foreground pill remains */}
                  <div className="rounded-full border border-white/10 bg-white/5 px-5 py-3 text-center backdrop-blur">
                    Octopyder · Red Teaming · SIEM Automation
                  </div>

                  {/* Local styles for code rain animation */}
                  <style
                    dangerouslySetInnerHTML={{
                      __html: `
                  @keyframes code-scroll {
                    0% { transform: translateY(0); }
                    100% { transform: translateY(-100%); }
                  }
                  .code-stream {
                    position: absolute;
                    left: 0;
                    right: 0;
                    top: 0;
                    margin: 0;
                    padding: 16px 20px;
                    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
                    font-size: 12px;
                    line-height: 1.35rem;
                    color: rgba(0, 229, 255, 0.85);
                    text-shadow: 0 0 12px rgba(0,229,255,0.25), 0 0 24px rgba(122,94,255,0.25);
                    background: linear-gradient(180deg, rgba(10,8,32,0.35), rgba(16,11,46,0.35));
                    border-top: 1px solid rgba(255,255,255,0.06);
                    border-bottom: 1px solid rgba(255,255,255,0.06);
                    white-space: pre;
                    animation: code-scroll 22s linear infinite;
                  }
                  .code-stream.code-stream--dup {
                    top: 100%;
                  }

                  /* --- CYBERPUNK GLITCH + HACKING SIM (LOOP) --- */
                  .glitch-banner {
                    position: absolute;
                    top: 9%;
                    left: 50%;
                    transform: translateX(-50%);
                    text-transform: uppercase;
                    letter-spacing: 0.18em;
                    z-index: 1;
                  }
                  .glitch {
                    position: relative;
                    display: inline-block;
                    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
                    font-weight: 700;
                    font-size: 12px;
                    color: rgba(255,255,255,.9);
                    text-shadow:
                      0 0 10px rgba(0,229,255,.35),
                      0 0 18px rgba(122,94,255,.35);
                    animation: flicker 4s ease-in-out infinite;
                  }
                  .glitch::before,
                  .glitch::after {
                    content: attr(data-text);
                    position: absolute;
                    inset: 0;
                    mix-blend-mode: screen;
                    pointer-events: none;
                  }
                  .glitch::before {
                    color: #0ff;
                    transform: translate(-1px, 0);
                    clip-path: inset(0 0 60% 0);
                    animation: glitchShiftA 2.2s steps(8) infinite;
                    text-shadow: -2px 0 4px rgba(0,229,255,.6);
                  }
                  .glitch::after {
                    color: #f0f;
                    transform: translate(1px, 0);
                    clip-path: inset(40% 0 0 0);
                    animation: glitchShiftB 2.2s steps(8) infinite;
                    text-shadow: 2px 0 4px rgba(230,66,248,.6);
                  }
                  @keyframes flicker {
                    0%, 100% { opacity: .95 }
                    10% { opacity: .6 }
                    11% { opacity: 1 }
                    20% { opacity: .7 }
                    21% { opacity: 1 }
                    60% { opacity: .85 }
                  }
                  @keyframes glitchShiftA {
                    0% { transform: translate(-1px, 0) }
                    20% { transform: translate(-2px, -1px) }
                    40% { transform: translate(1px, 1px) }
                    60% { transform: translate(-1px, 1px) }
                    80% { transform: translate(2px, -1px) }
                    100% { transform: translate(-1px, 0) }
                  }
                  @keyframes glitchShiftB {
                    0% { transform: translate(1px, 0) }
                    20% { transform: translate(2px, 1px) }
                    40% { transform: translate(-1px, -1px) }
                    60% { transform: translate(1px, -1px) }
                    80% { transform: translate(-2px, 1px) }
                    100% { transform: translate(1px, 0) }
                  }

                  .pulse-ring {
                    position: absolute;
                    left: 50%;
                    top: 50%;
                    width: 220px;
                    height: 220px;
                    transform: translate(-50%, -50%);
                    border-radius: 9999px;
                    border: 1px solid rgba(255,255,255,.08);
                    box-shadow: 0 0 0 0 rgba(0,229,255,.45);
                    animation: ringPulse 3s ease-out infinite;
                  }
                  .pulse-ring.delay-300 { animation-delay: .3s; }
                  @keyframes ringPulse {
                    0% { box-shadow: 0 0 0 0 rgba(0,229,255,.45); opacity: 1 }
                    100% { box-shadow: 0 0 0 64px rgba(0,229,255,0); opacity: 0 }
                  }

                  .hack-ticker {
                    position: absolute;
                    left: 0; right: 0; bottom: 8px;
                    overflow: hidden;
                    white-space: nowrap;
                    padding: 4px 0;
                    background: linear-gradient(180deg, rgba(10,8,32,0.15), rgba(16,11,46,0.15));
                    border-top: 1px solid rgba(255,255,255,0.06);
                    border-bottom: 1px solid rgba(255,255,255,0.06);
                    mask-image: linear-gradient(to right, transparent, black 10%, black 90%, transparent);
                  }
                  .hack-track {
                    display: inline-block;
                    padding-left: 100%;
                    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
                    font-size: 11px;
                    color: rgba(0,229,255,.9);
                    text-shadow: 0 0 10px rgba(0,229,255,.35), 0 0 18px rgba(122,94,255,.35);
                    animation: ticker 20s linear infinite;
                  }
                  .hack-track.hack-track--dup { animation-delay: 10s; }
                  @keyframes ticker {
                    0% { transform: translateX(0) }
                    100% { transform: translateX(-100%) }
                  }

                  .glitch-noise {
                    position: absolute;
                    inset: 0;
                    opacity: .045;
                    mix-blend-mode: overlay;
                    background:
                      repeating-linear-gradient(0deg, rgba(255,255,255,.07) 0, rgba(255,255,255,.07) 1px, transparent 1px, transparent 3px),
                      repeating-linear-gradient(90deg, rgba(255,255,255,.03) 0, rgba(255,255,255,.03) 1px, transparent 1px, transparent 2px);
                    animation: noiseShift 2s steps(8) infinite;
                    pointer-events: none;
                  }
                  @keyframes noiseShift {
                    0% { background-position: 0 0, 0 0 }
                    100% { background-position: 0 6px, 6px 0 }
                  }
                `,
                    }}
                  />
                </div>
                <div className="pointer-events-none absolute inset-0 animate-pulse rounded-xl ring-1 ring-white/10" />
              </div>
            </GlassCard>
          </div>
        </div>
      </section>

      <FeatureStrip />
      <HowItWorks />
      <ProvidersScatter />
      <ScenarioExplorer />
      <FAQ />

      {/* Final CTA */}
      <section className="text-center">
        <GlassCard className="mx-auto max-w-4xl p-10">
          <h2 className="text-3xl font-bold">Ready to secure the future?</h2>
          <p className="mt-2 text-white/80">
            Let’s collaborate on research, penetration testing, or security automation.
          </p>
          <div className="mt-6 flex items-center justify-center gap-3">
            <Link href="/experience">
              <Button size="lg" className="neon-btn-primary">
                See Experience
              </Button>
            </Link>
            <Link href="/achievements">
              <Button size="lg" variant="outline" className="neon-btn-outline bg-transparent">
                Achievements
              </Button>
            </Link>
          </div>
        </GlassCard>
      </section>
    </div>
  )
}
