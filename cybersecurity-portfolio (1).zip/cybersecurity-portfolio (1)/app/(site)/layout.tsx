"use client"

import { usePathname } from "next/navigation"
import { AnimatePresence, motion } from "framer-motion"
import { type PropsWithChildren, useEffect, useState } from "react"
import { Toaster } from "@/components/ui/toaster"
import { NavBar } from "@/components/nav-bar"
import { SiteFooter } from "@/components/site-footer"
import { CyberBackground } from "@/components/cyber-background"
import { Chatbot } from "@/components/chatbot"

export default function SiteLayout({ children }: PropsWithChildren) {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  return (
    <div className="relative min-h-dvh bg-gradient-to-b from-[#0B0820] via-[#100B2E] to-[#0B0820] text-white">
      {/* Parallax background + particle field + style reference overlay */}
      <CyberBackground
        referenceImageUrl="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AI%20Landing%20Page.jpg-4FEylGHdJieDYkTbYT897TFCDuKm10.jpeg"
        intensity="medium"
      />

      <div className="relative z-10">
        <NavBar gmail="iaminfinite03@gmail.com" linkedin="https://linkedin.com/in/your-handle" />

        <main aria-live="polite" className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          {/* Page transition wrapper */}
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, x: 40, filter: "blur(4px)" }}
              animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, x: -40, filter: "blur(4px)" }}
              transition={{ duration: 0.5, ease: [0.2, 0.8, 0.2, 1] }}
              className="pt-20 pb-16"
            >
              {mounted && children}
            </motion.div>
          </AnimatePresence>
        </main>

        <SiteFooter />
      </div>

      <Chatbot />
      <Toaster />
    </div>
  )
}
