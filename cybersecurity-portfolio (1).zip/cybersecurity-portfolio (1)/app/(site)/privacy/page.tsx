import { GlassCard } from "@/components/glass-card"

export default function PrivacyPage() {
  return (
    <div className="space-y-8">
      <header className="text-center">
        <h1 className="text-4xl font-bold">Privacy Policy</h1>
        <p className="mt-2 text-white/80">
          How this site handles your information and the measures taken to protect your privacy.
        </p>
      </header>

      <GlassCard className="p-6 space-y-3">
        <h2 className="text-xl font-semibold">What we collect</h2>
        <p className="text-white/80">
          This website does not require account creation. If you submit the contact form, we collect your name, email,
          and message to respond to your inquiry. We do not sell your data.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-3">
        <h2 className="text-xl font-semibold">Analytics and cookies</h2>
        <p className="text-white/80">
          We may use privacy-friendly analytics to understand site usage. Cookies, if any, are only used for essential
          functionality and are not used to track you across sites.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-3">
        <h2 className="text-xl font-semibold">Third-party services</h2>
        <p className="text-white/80">
          If integrated, external providers (e.g., AI APIs) receive only the minimum data needed to operate the feature.
          They are subject to their own privacy policies.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-3">
        <h2 className="text-xl font-semibold">Data retention</h2>
        <p className="text-white/80">
          Contact form submissions are kept only as long as necessary to process your request, then deleted. No
          long-term personal profiles are created from your visits.
        </p>
      </GlassCard>

      <GlassCard className="p-6 space-y-3">
        <h2 className="text-xl font-semibold">Your choices</h2>
        <ul className="list-disc space-y-2 pl-5 text-white/80">
          <li>You may request deletion of your contact message records.</li>
          <li>You may choose not to use optional features that require external services.</li>
        </ul>
      </GlassCard>

      <GlassCard className="p-6 space-y-3">
        <h2 className="text-xl font-semibold">Contact</h2>
        <p className="text-white/80">For privacy requests, email: iaminfinite03@gmail.com</p>
      </GlassCard>
    </div>
  )
}
