import type { NextRequest } from "next/server"
import { generateText } from "ai"
import { groq } from "@ai-sdk/groq"
import { xai } from "@ai-sdk/xai"
import { openai } from "@ai-sdk/openai"

const SYSTEM_PROMPT = `You are MaYa, the portfolio assistant for Anant Kumar.
Be friendly, witty, concise, and ethical (lab-only guidance).
You know site pages: Home, Projects, Skills, Lab, Experience, Achievements, Blog, About, Contact.
If asked for illegal activity, refuse and provide safe alternatives and learning resources.`

export async function POST(req: NextRequest) {
  try {
    const { prompt } = await req.json()
    if (!prompt || typeof prompt !== "string") {
      return Response.json({ error: "Invalid prompt" }, { status: 400 })
    }

    const hasOpenAI = !!process.env.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
    const hasGroq = !!process.env.GROQ_API_KEY
    const hasXAI = !!process.env.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

    if (hasOpenAI) {
      const { text } = await generateText({
        model: openai("gpt-4o-mini"),
        system: SYSTEM_PROMPT,
        prompt,
      })
      return Response.json({ text })
    } else if (hasGroq) {
      const { text } = await generateText({
        model: groq("llama-3.1-8b-instant"),
        system: SYSTEM_PROMPT,
        prompt,
      })
      return Response.json({ text })
    } else if (hasXAI) {
      const { text } = await generateText({
        model: xai("grok-3"),
        system: SYSTEM_PROMPT,
        prompt,
      })
      return Response.json({ text })
    }

    const canned = demoReply(prompt)
    return Response.json({ text: canned })
  } catch {
    return Response.json({ error: "Server error" }, { status: 500 })
  }
}

function demoReply(p: string): string {
  const lower = p.toLowerCase()
  if (lower.includes("experience")) {
    return "I interned as a SOC Analyst & Penetration Tester at Octopyder—want to see the Experience page?"
  }
  if (lower.includes("skills")) {
    return "Core areas: PT/VA, IDS/IPS, SIEM, Python automation; tools include Metasploit, Wireshark, Burp, ZAP, Nmap."
  }
  if (lower.includes("achievements") || lower.includes("certifications")) {
    return "Hackathons and training include IIT Dharwad Parsec, METACTF, OCEH, and more—check Achievements."
  }
  if (lower.includes("contact")) {
    return "Reach Anant via Gmail (iaminfinite03@gmail.com), phone, or LinkedIn on the Contact page."
  }
  return "I’m MaYa. I can guide you to Projects, Skills, Lab, Experience, or Achievements—what are you exploring?"
}
