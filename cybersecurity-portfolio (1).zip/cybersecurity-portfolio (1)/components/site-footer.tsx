export function SiteFooter() {
  return (
    <footer aria-label="Footer" className="relative mt-20 border-t border-white/10 bg-white/5/10">
      <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-3">
          <div>
            <h4 className="font-semibold">Legal</h4>
            <ul className="mt-3 space-y-2 text-white/80">
              <li>
                <a className="hover:underline" href="/legal">
                  Legal
                </a>
              </li>
              <li>
                <a className="hover:underline" href="/privacy">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a className="hover:underline" href="/terms">
                  Terms of Service
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold">Subscribe</h4>
            <p className="mt-3 text-white/80">Get updates on new projects.</p>
            <form className="mt-3 flex items-center gap-2">
              <input
                className="w-full rounded-md border border-white/15 bg-white/5 px-3 py-2 text-sm placeholder:text-white/50 focus:outline-none"
                placeholder="Enter your email"
              />
              <button className="rounded-md bg-gradient-to-r from-fuchsia-500 to-violet-500 px-3 py-2 text-sm">
                Join
              </button>
            </form>
          </div>
          <div>
            <h4 className="font-semibold">Social</h4>
            <div className="mt-3 flex gap-3 text-white/80">
              <a
                href="https://www.linkedin.com/in/anant-kumar-9a2923319/"
                target="_blank"
                rel="noreferrer"
                className="hover:text-white"
                aria-label="LinkedIn (opens in a new tab)"
              >
                LinkedIn
              </a>
            </div>
          </div>
        </div>
        <div className="mt-10 text-xs text-white/60">
          © {new Date().getFullYear()} Anant Kumar. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
