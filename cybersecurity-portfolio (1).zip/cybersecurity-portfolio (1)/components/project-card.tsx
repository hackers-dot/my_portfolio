import { GlassCard } from "./glass-card"

type Props = {
  title?: string
  summary?: string
  stack?: string[]
  highlights?: string[]
}

export function ProjectCard({
  title = "Project Name",
  summary = "Short summary goes here",
  stack = ["Tool A", "Tool B"],
  highlights = ["Key Result 1", "Key Result 2"],
}: Props) {
  return (
    <GlassCard className="p-6">
      <div className="space-y-3">
        <h3 className="text-xl font-semibold">{title}</h3>
        <p className="text-white/80">{summary}</p>
        <div className="flex flex-wrap gap-2">
          {stack.map((t) => (
            <span key={t} className="rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-xs text-white/90">
              {t}
            </span>
          ))}
        </div>
        <ul className="mt-2 grid gap-2">
          {highlights.map((h) => (
            <li key={h} className="rounded-md border border-white/10 bg-white/5 px-3 py-2 text-sm text-white/90">
              {h}
            </li>
          ))}
        </ul>
      </div>
    </GlassCard>
  )
}
