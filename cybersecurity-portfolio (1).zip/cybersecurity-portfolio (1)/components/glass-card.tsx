import { cn } from "@/lib/utils"
import type { HTMLAttributes } from "react"

export function GlassCard({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-white/10 bg-white/5 p-4 shadow-[0_0_40px_-20px_rgba(124,58,237,0.6)] backdrop-blur-md",
        "supports-[backdrop-filter]:bg-white/5",
        className,
      )}
      {...props}
    />
  )
}
