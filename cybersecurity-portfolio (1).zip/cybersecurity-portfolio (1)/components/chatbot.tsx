"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { MessageCircle, Send, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

type ChatMsg = { role: "user" | "assistant"; content: string }

export function Chatbot() {
  const [open, setOpen] = useState(true)
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [messages, setMessages] = useState<ChatMsg[]>([
    {
      role: "assistant",
      content: "Hi, I’m MaYa ✨ Your cyberpunk portfolio guide. Want projects, skills, or lab info?",
    },
  ])
  const endRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, open])

  async function sendMessage(e?: React.FormEvent) {
    e?.preventDefault()
    const text = input.trim()
    if (!text) return
    const next = [...messages, { role: "user", content: text }]
    setMessages(next)
    setInput("")
    setLoading(true)
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ prompt: text }),
      })
      const data = await res.json()
      setMessages((m) => [...m, { role: "assistant", content: data.text }])
    } catch {
      setMessages((m) => [...m, { role: "assistant", content: "Network hiccup. Try again in a bit ✨" }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="pointer-events-none fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      {/* Toggle Button */}
      <button
        onClick={() => setOpen((o) => !o)}
        className="pointer-events-auto group relative flex h-12 w-12 items-center justify-center rounded-full border border-white/20 bg-white/10 backdrop-blur transition hover:bg-white/15"
        aria-label="Toggle chatbot"
      >
        <div className="absolute inset-0 -z-10 animate-ping rounded-full bg-gradient-to-tr from-fuchsia-500/30 to-cyan-400/30 delay-100" />
        <MessageCircle className="h-5 w-5 text-white" />
      </button>

      {/* Panel */}
      {open && (
        <div className="pointer-events-auto w-[92vw] max-w-sm overflow-hidden rounded-2xl border border-white/15 bg-white/10 backdrop-blur">
          <div className="flex items-center justify-between gap-2 border-b border-white/10 bg-gradient-to-r from-fuchsia-500/20 via-violet-500/10 to-cyan-500/20 px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="relative h-7 w-7">
                <div className="absolute inset-0 animate-pulse rounded-full bg-gradient-to-tr from-fuchsia-400 to-cyan-300 blur-[2px]" />
                <div className="relative grid h-7 w-7 place-items-center rounded-full border border-white/30 bg-white/20 text-xs font-bold text-white">
                  MY
                </div>
              </div>
              <div className="text-sm font-medium">MaYa</div>
            </div>
            <button onClick={() => setOpen(false)} aria-label="Close" className="rounded-md p-1 hover:bg-white/10">
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="max-h-[50vh] space-y-3 overflow-y-auto p-4">
            {messages.map((m, i) => (
              <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
                <div
                  className={cn(
                    "max-w-[80%] rounded-2xl px-3 py-2 text-sm",
                    m.role === "user"
                      ? "bg-gradient-to-r from-fuchsia-500/20 to-violet-500/20 border border-white/15"
                      : "bg-gradient-to-r from-violet-500/15 to-cyan-500/15 border border-white/10",
                  )}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="relative max-w-[80%] rounded-2xl border border-white/10 bg-white/10 px-3 py-2 text-sm">
                  <span className="inline-flex gap-1">
                    <span className="block h-2 w-2 animate-bounce rounded-full bg-fuchsia-300" />
                    <span className="block h-2 w-2 animate-bounce rounded-full bg-violet-300 [animation-delay:120ms]" />
                    <span className="block h-2 w-2 animate-bounce rounded-full bg-cyan-300 [animation-delay:240ms]" />
                  </span>
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          <form onSubmit={sendMessage} className="flex items-center gap-2 border-t border-white/10 p-3">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about projects, skills, labs…"
              className="bg-white/10"
            />
            <Button type="submit" className="neon-btn-primary" disabled={loading || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      )}
    </div>
  )
}
