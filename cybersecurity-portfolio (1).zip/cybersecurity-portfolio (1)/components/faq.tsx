import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { GlassCard } from "./glass-card"

export function FAQ() {
  const items = [
    { q: "Do you test on live systems?", a: "No. All testing is done in isolated labs or with explicit permission." },
    {
      q: "Which tools do you use most?",
      a: "Wireshark, Nmap, Burp Suite, Metasploit, Suricata/Snort, VirtualBox/VMware, Docker.",
    },
    { q: "Can we collaborate on a project?", a: "Absolutely. Reach me via Gmail or LinkedIn on the Contact page." },
    { q: "Do you write reports?", a: "Yes. I provide concise write-ups, diagrams, and remediation notes." },
  ]
  return (
    <section className="space-y-6">
      <header className="text-center">
        <h2 className="text-3xl font-bold">Have a question?</h2>
      </header>
      <GlassCard className="p-4 md:p-6">
        <Accordion type="single" collapsible className="w-full">
          {items.map((it, idx) => (
            <AccordionItem key={idx} value={`item-${idx}`}>
              <AccordionTrigger>{it.q}</AccordionTrigger>
              <AccordionContent className="text-white/80">{it.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </GlassCard>
    </section>
  )
}
