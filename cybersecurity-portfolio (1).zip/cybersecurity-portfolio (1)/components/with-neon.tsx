"use client"

import { useEffect } from "react"
import { NeonStyles } from "./neon-styles"

export function WithNeon() {
  useEffect(() => {
    // Respect prefers-reduced-motion by disabling heavy effects (example hook)
    const media = window.matchMedia("(prefers-reduced-motion: reduce)")
    if (media.matches) {
      document.body.classList.add("reduce-motion")
    }
  }, [])
  return <NeonStyles />
}
