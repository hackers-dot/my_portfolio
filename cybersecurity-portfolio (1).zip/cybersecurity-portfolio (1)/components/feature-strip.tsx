import { GlassCard } from "./glass-card"
import { Users, ServerCog, Beaker } from "lucide-react"

export function FeatureStrip() {
  const items = [
    {
      title: "Hands-on Labs",
      desc: "Isolated environments for safe, ethical testing.",
      icon: Beaker,
    },
    {
      title: "Hackathons & CTFs",
      desc: "Where I learn fastest and build under pressure.",
      icon: Users,
    },
    {
      title: "From Local to Cloud",
      desc: "PHP/SQL/HTML prototypes I can harden and ship.",
      icon: ServerCog,
    },
  ]

  return (
    <section className="relative">
      <GlassCard className="p-4 md:p-6">
        <div className="grid gap-6 md:grid-cols-3">
          {items.map((it) => (
            <div
              key={it.title}
              className="flex items-start gap-4 rounded-xl border border-white/10 bg-white/5 p-5 backdrop-blur"
            >
              <it.icon className="h-6 w-6 text-fuchsia-300" />
              <div>
                <div className="font-semibold">{it.title}</div>
                <div className="text-sm text-white/80">{it.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </GlassCard>
    </section>
  )
}
