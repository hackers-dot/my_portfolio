"use client"

import { useState } from "react"
import { GlassCard } from "./glass-card"
import { ChevronLeft, ChevronRight, Play } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ScenarioExplorer() {
  const scenarios = [
    {
      label: "Detect port scan",
      title: "Detecting Nmap scans",
      bullets: ["Flow thresholds", "Burst detection", "Alert tuning", "Noise reduction"],
    },
    {
      label: "DDoS mitigation tests",
      title: "Rate limiting at edges",
      bullets: ["Token buckets", "WAF rules", "Upstream protection", "Failover drills"],
    },
    {
      label: "Password policy audit",
      title: "Lockout thresholds",
      bullets: ["Login throttling", "Lockout decay", "SIEM correlation", "Alerts hygiene"],
    },
    {
      label: "App input validation",
      title: "Hardening forms",
      bullets: ["Server-side checks", "Sanitization", "CSP basics", "Error handling"],
    },
  ]
  const [idx, setIdx] = useState(0)
  const current = scenarios[idx]

  return (
    <section className="space-y-6">
      <header className="text-center">
        <h2 className="text-3xl font-bold">Endless possibilities · Infinite results</h2>
      </header>

      <div className="grid gap-6 md:grid-cols-[1fr_420px_1fr]">
        <div className="hidden items-center justify-end md:flex">
          <Button
            variant="outline"
            className="neon-btn-outline bg-transparent"
            onClick={() => setIdx((i) => (i - 1 + scenarios.length) % scenarios.length)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>

        <GlassCard className="p-6">
          <div className="mx-auto max-w-md text-center">
            <div className="inline-flex items-center gap-2 rounded-md border border-white/10 bg-white/5 px-3 py-1 text-sm">
              <Play className="h-4 w-4 text-cyan-300" />
              {current.label}
            </div>
            <h3 className="mt-4 text-2xl font-semibold">{current.title}</h3>
            <ul className="mt-4 grid gap-2 text-left text-white/80">
              {current.bullets.map((b) => (
                <li key={b} className="rounded-md border border-white/10 bg-white/5 px-3 py-2">
                  {b}
                </li>
              ))}
            </ul>
            <div className="mt-5 text-sm text-white/70">See more results</div>
          </div>
        </GlassCard>

        <div className="hidden items-center md:flex">
          <Button
            variant="outline"
            className="neon-btn-outline bg-transparent"
            onClick={() => setIdx((i) => (i + 1) % scenarios.length)}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="no-scrollbar flex items-center gap-3 overflow-x-auto py-2">
        {scenarios.map((s, i) => (
          <button
            key={s.label}
            onClick={() => setIdx(i)}
            className={`shrink-0 rounded-full border px-4 py-2 text-sm backdrop-blur ${
              i === idx ? "border-fuchsia-400 bg-fuchsia-400/10" : "border-white/10 bg-white/5 hover:bg-white/10"
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>
    </section>
  )
}
