"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

export function NavBar({ gmail = "iaminfinite03@gmail.com", linkedin = "https://linkedin.com/in/your-handle" }) {
  const pathname = usePathname()
  const resolvedLinkedIn =
    linkedin && linkedin !== "https://linkedin.com/in/your-handle"
      ? linkedin
      : "https://www.linkedin.com/in/anant-kumar-9a2923319/"

  const links = [
    { href: "/", label: "Home" },
    { href: "/projects", label: "Projects" },
    { href: "/skills", label: "Skills" },
    { href: "/lab", label: "Lab" },
    { href: "/experience", label: "Experience" },
    { href: "/achievements", label: "Achievements" },
    { href: "/blog", label: "Blog" },
    { href: "/about", label: "About" },
    { href: "/contact", label: "Contact" },
  ]
  return (
    <header className="fixed inset-x-0 top-0 z-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 backdrop-blur supports-[backdrop-filter]:bg-white/5">
          <div className="flex items-center justify-between gap-6">
            <Link href="/" className="text-lg font-semibold tracking-tight">
              {"<"}PORTFOLIO{">"}
            </Link>
            <nav className="hidden gap-4 md:flex">
              {links.map((l) => (
                <Link
                  key={l.href}
                  href={l.href}
                  className={cn(
                    "rounded-md px-3 py-1.5 text-sm text-white/85 hover:text-white",
                    pathname === l.href && "bg-white/10 text-white",
                  )}
                >
                  {l.label}
                </Link>
              ))}
            </nav>
            <div className="hidden items-center gap-2 sm:flex">
              <a href={`mailto:${gmail}`}>
                <Button size="sm" variant="link" className="neon-btn-outline bg-transparent">
                  Gmail
                </Button>
              </a>
              <a
                href={resolvedLinkedIn}
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn profile (opens in a new tab)"
              >
                <Button size="sm" className="neon-btn-primary">
                  LinkedIn
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
