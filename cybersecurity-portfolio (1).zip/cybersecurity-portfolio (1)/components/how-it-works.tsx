import { GlassCard } from "./glass-card"
import { ListOrdered, Construction, Share2, Heart, MessageCircle } from "lucide-react"

// Hacker-style animated boxes for each step

function SimBox() {
  // DoS/DDoS attack simulation effect (traffic bars + scrolling IDS/SIEM logs)
  return (
    <div
      className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border border-white/10 bg-white/5 backdrop-blur"
      aria-hidden="true"
    >
      {/* Faint grid */}
      <div className="absolute inset-0 sim-grid" />
      {/* Traffic bars */}
      <div className="absolute inset-x-0 bottom-0 flex h-2/3 items-end gap-1 px-3 pb-3">
        {Array.from({ length: 22 }).map((_, i) => (
          <span
            key={i}
            className="sim-bar"
            style={{
              animationDelay: `${(i % 7) * 0.2}s`,
              height: `${30 + ((i * 37) % 50)}%`,
            }}
          />
        ))}
      </div>
      {/* Scrolling terminal logs */}
      <div className="pointer-events-none absolute left-0 top-0 h-full w-full overflow-hidden [mask-image:linear-gradient(to_bottom,transparent,rgba(0,0,0,0.75)_12%,rgba(0,0,0,0.9)_88%,transparent)]">
        <pre className="sim-logs">
          {`[LAB] INIT ddos_surge target=10.0.0.5 rate=10kpps iface=eth1
[IDS] ET DOS Possible SYN Flood src=10.0.0.10 dst=10.0.0.5 sid=220001
[SIEM] rule=anomaly.ddos corr=3 severity=HIGH action=dash+notify
[WAF] throttled /login 429s=64 upstream=api-01
[LAB] Hydra auth spray user=admin delay=150ms lockout=on
[IDS] SSH brute-force alarming failures=7 threshold=10
[PCAP] write /var/lab/pcap/ssh-ddos_01.pcap size=12.4MB
[SIEM] p95=138ms err=0.9% tag=BLUETEAM-INVESTIGATE
[LAB] tcpreplay profile="burst-3" speed=10Mbps iface=eth2
[IDS] HTTP SQLi probe id=ET-WEB-SQLI MED payload="or 1=1--"
[LAB] cleanup iptables, tc; export artifacts=pcap,alerts,siem.json
[NOTE] Isolated lab only. Do not test on live systems.`}
        </pre>
        <pre className="sim-logs sim-logs--dup">
          {`[LAB] INIT ddos_surge target=10.0.0.5 rate=10kpps iface=eth1
[IDS] ET DOS Possible SYN Flood src=10.0.0.10 dst=10.0.0.5 sid=220001
[SIEM] rule=anomaly.ddos corr=3 severity=HIGH action=dash+notify
[WAF] throttled /login 429s=64 upstream=api-01
[LAB] Hydra auth spray user=admin delay=150ms lockout=on
[IDS] SSH brute-force alarming failures=7 threshold=10
[PCAP] write /var/lab/pcap/ssh-ddos_01.pcap size=12.4MB
[SIEM] p95=138ms err=0.9% tag=BLUETEAM-INVESTIGATE
[LAB] tcpreplay profile="burst-3" speed=10Mbps iface=eth2
[IDS] HTTP SQLi probe id=ET-WEB-SQLI MED payload="or 1=1--"
[LAB] cleanup iptables, tc; export artifacts=pcap,alerts,siem.json
[NOTE] Isolated lab only. Do not test on live systems.`}
        </pre>
      </div>

      {/* Local styles */}
      <style
        dangerouslySetInnerHTML={{
          __html: `
          .sim-grid {
            background-image:
              linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px);
            background-size: 24px 24px, 24px 24px;
            filter: drop-shadow(0 0 24px rgba(122,94,255,0.25));
          }
          .sim-bar {
            width: 10px;
            background: linear-gradient(180deg, rgba(0,229,255,0.7), rgba(122,94,255,0.6));
            box-shadow: 0 0 16px rgba(0,229,255,0.35), inset 0 0 8px rgba(122,94,255,0.25);
            border-radius: 6px 6px 0 0;
            animation: simPulse 1.6s ease-in-out infinite;
          }
          @keyframes simPulse {
            0%,100% { transform: scaleY(0.85); filter: brightness(0.9); }
            50%     { transform: scaleY(1.15); filter: brightness(1.15); }
          }
          .sim-logs {
            position: absolute;
            inset: 0 auto auto 0;
            width: 100%;
            color: rgba(0,229,255,0.85);
            text-shadow: 0 0 8px rgba(0,229,255,0.25), 0 0 14px rgba(122,94,255,0.25);
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            font-size: 12px;
            line-height: 1.35rem;
            padding: 12px 16px;
            margin: 0;
            white-space: pre;
            animation: simScroll 20s linear infinite;
            background: linear-gradient(180deg, rgba(10,8,32,0.25), rgba(16,11,46,0.25));
            border-top: 1px solid rgba(255,255,255,0.06);
            border-bottom: 1px solid rgba(255,255,255,0.06);
          }
          .sim-logs--dup { top: 100%; }
          @keyframes simScroll {
            0% { transform: translateY(0%); }
            100% { transform: translateY(-100%); }
          }
        `,
        }}
      />
    </div>
  )
}

function WebHardenBox() {
  // Simple social-app effect: floating app chips and a phone feed skeleton
  return (
    <div
      className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border border-white/10 bg-white/5 backdrop-blur"
      aria-hidden="true"
    >
      {/* Floating social app chips (Insta, Facebook, etc.) */}
      <div className="absolute left-2 top-1/2 -translate-y-1/2">
        <div className="flex flex-col gap-2">
          {["Insta", "Facebook", "X", "LinkedIn", "YouTube", "GitHub"].map((t, i) => (
            <span key={t} className="app-chip app-float" style={{ animationDelay: `${i * 0.25}s` }}>
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* Center phone mock with feed skeleton (no code text shown) */}
      <div className="absolute inset-0 grid place-items-center">
        <div className="phone">
          <div className="phone-notch" />
          <div className="phone-screen">
            {/* Header: avatar + lines */}
            <div className="flex items-center gap-3 px-3 py-2">
              <div className="avatar-skel shimmer" />
              <div className="flex-1 space-y-1">
                <div className="line-skel shimmer w-2/3" />
                <div className="line-skel shimmer w-1/3 opacity-70" />
              </div>
            </div>

            {/* Media */}
            <div className="media-skel shimmer mx-3 my-2" />

            {/* Actions */}
            <div className="flex items-center gap-3 px-3 py-1">
              <button className="act-btn" aria-label="Like">
                <Heart className="h-4 w-4" />
              </button>
              <button className="act-btn" aria-label="Comment">
                <MessageCircle className="h-4 w-4" />
              </button>
              <button className="act-btn" aria-label="Share">
                <Share2 className="h-4 w-4" />
              </button>
              <div className="ml-auto flex items-center gap-2">
                <span className="count-chip">1.2k</span>
                <span className="count-chip">318</span>
              </div>
            </div>

            {/* Comments skeleton */}
            <div className="px-3 pb-3">
              <div className="line-skel shimmer w-5/6" />
              <div className="mt-1 line-skel shimmer w-2/3 opacity-80" />
            </div>
          </div>
        </div>
      </div>

      {/* Subtle background glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-fuchsia-500/15 blur-3xl" />
        <div className="absolute -bottom-24 -left-24 h-64 w-64 rounded-full bg-cyan-400/15 blur-3xl" />
      </div>

      {/* Local styles for simple effects */}
      <style
        dangerouslySetInnerHTML={{
          __html: `
            .app-chip {
              display:inline-flex; align-items:center; justify-content:center;
              padding:6px 10px; border-radius:9999px;
              background: linear-gradient(90deg, rgba(230,66,248,.18), rgba(122,94,255,.18), rgba(0,229,255,.18));
              border:1px solid rgba(255,255,255,.18);
              color:#fff; font-size:11px;
              box-shadow: 0 0 14px rgba(122,94,255,.35);
            }
            @keyframes floatY { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-6px) } }
            .app-float { animation: floatY 3s ease-in-out infinite; }

            .phone {
              width: 250px; aspect-ratio: 9/19;
              border-radius: 28px;
              background: linear-gradient(180deg, rgba(255,255,255,.06), rgba(255,255,255,.02));
              border: 1px solid rgba(255,255,255,.2);
              box-shadow: 0 24px 60px -20px rgba(122,94,255,.55);
              position: relative;
              overflow: hidden;
              backdrop-filter: blur(6px);
            }
            .phone-notch {
              position: absolute; top: 6px; left: 50%;
              transform: translateX(-50%);
              width: 40%;
              height: 8px;
              background: rgba(255,255,255,.12);
              border-radius: 0 0 12px 12px;
            }
            .phone-screen {
              position: absolute; inset: 12px 8px 8px 8px;
              border-radius: 18px;
              background: rgba(6,7,16,.45);
              border: 1px solid rgba(255,255,255,.08);
              overflow: hidden;
            }
            .avatar-skel {
              width: 28px; height: 28px; border-radius: 9999px;
              background: rgba(255,255,255,.12);
              border: 1px solid rgba(255,255,255,.15);
            }
            .line-skel {
              height: 10px; border-radius: 8px;
              background: rgba(255,255,255,.10);
              border: 1px solid rgba(255,255,255,.08);
            }
            .media-skel {
              height: 140px; border-radius: 12px;
              background:
                radial-gradient(60% 60% at 20% 10%, rgba(230,66,248,.16), transparent),
                radial-gradient(60% 60% at 80% 90%, rgba(0,229,255,.16), transparent),
                rgba(255,255,255,.06);
              border: 1px solid rgba(255,255,255,.12);
            }
            .act-btn {
              display:inline-flex; align-items:center; justify-content:center;
              width:32px; height:28px;
              border-radius:10px;
              background: rgba(255,255,255,.08);
              border: 1px solid rgba(255,255,255,.14);
              color: #fff;
            }
            .act-btn:hover { filter: brightness(1.1); }
            .count-chip {
              display:inline-flex; align-items:center; padding:2px 8px;
              border-radius:9999px; font-size:11px; color:#dff;
              background: rgba(0,229,255,.12);
              border: 1px solid rgba(255,255,255,.16);
              text-shadow: 0 0 10px rgba(0,229,255,.35);
            }
            @keyframes shimmer {
              0% { background-position: -200% 0; }
              100% { background-position: 200% 0; }
            }
            .shimmer {
              background-image: linear-gradient(90deg, rgba(255,255,255,0), rgba(255,255,255,.15), rgba(255,255,255,0));
              background-size: 200% 100%;
              animation: shimmer 2.4s linear infinite;
            }
          `,
        }}
      />
    </div>
  )
}

function ShareSimBox() {
  // "Extend & Share" simulation (packets flowing along curved paths between Write-ups -> Templates -> Demos)
  return (
    <div
      className="relative aspect-[4/3] w-full overflow-hidden rounded-lg border border-white/10 bg-white/5 backdrop-blur"
      aria-hidden="true"
    >
      {/* Node halos */}
      <div className="absolute inset-0 grid grid-cols-3 place-items-center px-4">
        {["Write-ups", "Templates", "Demos"].map((t) => (
          <div key={t} className="relative">
            <div className="node-halo" />
            <div className="z-10 rounded-xl border border-white/15 bg-white/10 px-3 py-2 text-xs text-white/90 backdrop-blur">
              {t}
            </div>
          </div>
        ))}
      </div>

      {/* Lanes: straight middle + two bezier curves */}
      <svg className="absolute inset-0" viewBox="0 0 100 100" preserveAspectRatio="none">
        <defs>
          <linearGradient id="laneGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="rgba(230,66,248,.6)" />
            <stop offset="50%" stopColor="rgba(122,94,255,.6)" />
            <stop offset="100%" stopColor="rgba(0,229,255,.6)" />
          </linearGradient>
        </defs>
        {/* top arc */}
        <path d="M 10 35 C 35 20, 65 20, 90 35" stroke="url(#laneGrad)" strokeWidth="0.6" fill="none" opacity="0.6" />
        {/* straight middle */}
        <path d="M 10 50 L 90 50" stroke="url(#laneGrad)" strokeWidth="0.6" fill="none" opacity="0.6" />
        {/* bottom arc */}
        <path d="M 10 65 C 35 80, 65 80, 90 65" stroke="url(#laneGrad)" strokeWidth="0.6" fill="none" opacity="0.6" />
      </svg>

      {/* Packets on curved/straight paths */}
      {Array.from({ length: 4 }).map((_, i) => (
        <span key={`a-${i}`} className="packet-curve curve-a" style={{ animationDelay: `${i * 0.6}s` }} />
      ))}
      {Array.from({ length: 5 }).map((_, i) => (
        <span key={`m-${i}`} className="packet-mid" style={{ animationDelay: `${i * 0.5}s` }} />
      ))}
      {Array.from({ length: 4 }).map((_, i) => (
        <span key={`c-${i}`} className="packet-curve curve-c" style={{ animationDelay: `${i * 0.7}s` }} />
      ))}

      {/* Arrival ripples near Demos node */}
      <div className="arrival-ripple" />
      <div className="arrival-ripple delay-300" />

      <style
        dangerouslySetInnerHTML={{
          __html: `
          /* Pulsing halos behind nodes */
          .node-halo::before, .node-halo::after {
            content: "";
            position: absolute;
            inset: -18px;
            border-radius: 9999px;
            background: radial-gradient(circle, rgba(122,94,255,.35), transparent 60%);
            filter: blur(8px);
            animation: haloPulse 2.6s ease-in-out infinite;
          }
          .node-halo::after {
            inset: -26px;
            background: radial-gradient(circle, rgba(0,229,255,.25), transparent 70%);
            animation-duration: 3.2s;
          }
          @keyframes haloPulse { 0%,100% { opacity: .55 } 50% { opacity: 1 } }

          /* Packets */
          .packet-mid, .packet-curve {
            position: absolute;
            width: 10px; height: 10px; border-radius: 9999px;
            background: radial-gradient(circle at 30% 30%, #00E5FF, #7A5EFF);
            box-shadow: 0 0 16px rgba(0,229,255,0.55), 0 0 24px rgba(122,94,255,0.45);
            opacity: .2;
          }

          /* Straight middle path animation (percent-of-box positioning) */
          .packet-mid {
            top: 50%; transform: translate(-50%, -50%);
            left: 10%;
            animation: midFlow 4s linear infinite;
          }
          @keyframes midFlow {
            0% { left: 10%; opacity: .2 }
            10% { opacity: 1 }
            50% { left: 50% }
            90% { opacity: 1 }
            100% { left: 90%; opacity: .2 }
          }

          /* Curved paths using offset-path */
          .packet-curve {
            offset-distance: 0%;
            animation: curveFlow 4.6s linear infinite;
          }
          .curve-a {
            top: 0; left: 0;
            offset-path: path("M 10 35 C 35 20, 65 20, 90 35");
          }
          .curve-c {
            top: 0; left: 0;
            offset-path: path("M 10 65 C 35 80, 65 80, 90 65");
            animation-duration: 5.2s;
          }
          @keyframes curveFlow {
            0%   { offset-distance: 0%; opacity: .2 }
            10%  { opacity: 1 }
            100% { offset-distance: 100%; opacity: .2 }
          }

          /* Arrival ripple near the right side (Demos) */
          .arrival-ripple {
            position: absolute;
            right: 42px; top: 50%;
            width: 8px; height: 8px; transform: translate(50%, -50%);
            border-radius: 9999px;
            box-shadow: 0 0 0 0 rgba(0,229,255,.5);
            animation: ripple 2.8s ease-out infinite;
          }
          .arrival-ripple.delay-300 { animation-delay: .3s; }
          @keyframes ripple {
            0% { box-shadow: 0 0 0 0 rgba(0,229,255,.5); opacity: 1 }
            100% { box-shadow: 0 0 0 28px rgba(0,229,255,0); opacity: 0 }
          }
        `,
        }}
      />
    </div>
  )
}

export function HowItWorks() {
  const steps = [
    {
      n: "01",
      title: "Run Simulations",
      desc: "DoS/DDoS, brute force (lab only), packet capture, IDS tuning.",
      icon: ListOrdered,
    },
    {
      n: "02",
      title: "Build & Harden",
      desc: "Threat modeling, baselines, secure defaults for web apps.",
      icon: Construction,
    },
    {
      n: "03",
      title: "Extend & Share",
      desc: "Write-ups, reproducible templates, and demos.",
      icon: Share2,
    },
  ]

  return (
    <section className="space-y-8">
      <header className="text-center">
        <h2 className="text-3xl font-bold">How does it work?</h2>
        <p className="mt-2 text-white/80">Explore my approach to building and testing securely.</p>
      </header>

      <div className="grid gap-6 md:grid-cols-3">
        {steps.map((s, idx) => (
          <GlassCard key={s.n} className="p-6">
            <div className="mb-3 inline-flex items-center gap-2 rounded-md border border-white/10 bg-white/5 px-3 py-1 text-sm">
              <s.icon className="h-4 w-4 text-cyan-300" />
              <span className="font-medium">{s.n}</span>
            </div>
            <h3 className="text-xl font-semibold">{s.title}</h3>
            <p className="mt-2 text-white/80">{s.desc}</p>
            <div className="mt-6">{idx === 0 ? <SimBox /> : idx === 1 ? <WebHardenBox /> : <ShareSimBox />}</div>
          </GlassCard>
        ))}
      </div>
    </section>
  )
}
