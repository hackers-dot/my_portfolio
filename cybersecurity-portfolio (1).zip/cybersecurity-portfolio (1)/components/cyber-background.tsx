"use client"

import { useEffect, useRef } from "react"

type Props = {
  referenceImageUrl?: string
  intensity?: "low" | "medium" | "high"
}

export function CyberBackground({
  referenceImageUrl = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AI%20Landing%20Page.jpg-4FEylGHdJieDYkTbYT897TFCDuKm10.jpeg",
  intensity = "medium",
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d", { alpha: true })
    if (!ctx) return

    let width = (canvas.width = window.innerWidth)
    let height = (canvas.height = window.innerHeight)
    let raf = 0
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    canvas.width = width * dpr
    canvas.height = height * dpr
    ctx.scale(dpr, dpr)

    const maxParticles = intensity === "high" ? 180 : intensity === "medium" ? 120 : 80
    const particles = Array.from({ length: maxParticles }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      r: Math.random() * 1.8 + 0.2,
      vx: (Math.random() - 0.5) * 0.2,
      vy: (Math.random() - 0.5) * 0.2,
      hue: 250 + Math.random() * 100, // purple-cyan range
    }))

    const img = new Image()
    img.crossOrigin = "anonymous"
    img.src = referenceImageUrl

    function draw() {
      ctx.clearRect(0, 0, width, height)

      // Nebula gradient background overlay (very faint)
      const g = ctx.createRadialGradient(
        width * 0.5,
        height * 0.3,
        0,
        width * 0.5,
        height * 0.3,
        Math.max(width, height) * 0.7,
      )
      g.addColorStop(0, "rgba(122,94,255,0.06)")
      g.addColorStop(0.5, "rgba(0,229,255,0.04)")
      g.addColorStop(1, "rgba(230,66,248,0.02)")
      ctx.fillStyle = g
      ctx.fillRect(0, 0, width, height)

      // Reference image overlay to guide style (soft blend)
      if (img.complete) {
        ctx.globalAlpha = 0.05
        ctx.drawImage(img, width - Math.min(600, width * 0.5), -40, Math.min(600, width * 0.5), Math.min(1200, height))
        ctx.globalAlpha = 1
      }

      // Particles
      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0) p.x = width
        if (p.x > width) p.x = 0
        if (p.y < 0) p.y = height
        if (p.y > height) p.y = 0

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fillStyle = `hsla(${p.hue}, 90%, 70%, 0.6)`
        ctx.fill()
      }

      // Occasional neon swirl stroke
      ctx.lineWidth = 2
      ctx.strokeStyle = "rgba(122,94,255,0.25)"
      ctx.beginPath()
      const cx = width * 0.35
      const cy = height * 0.25
      ctx.moveTo(0, cy)
      ctx.bezierCurveTo(cx * 0.6, cy - 60, cx * 1.2, cy + 40, width, cy - 20)
      ctx.stroke()

      raf = requestAnimationFrame(draw)
    }

    function onResize() {
      width = window.innerWidth
      height = window.innerHeight
      canvas.width = width * dpr
      canvas.height = height * dpr
      ctx.scale(dpr, dpr)
    }

    draw()
    window.addEventListener("resize", onResize)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener("resize", onResize)
    }
  }, [referenceImageUrl, intensity])

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10">
      <canvas ref={canvasRef} className="h-full w-full" />
    </div>
  )
}
