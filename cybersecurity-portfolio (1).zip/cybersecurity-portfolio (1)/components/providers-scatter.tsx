"use client"

import { useEffect, useRef } from "react"
import { GlassCard } from "./glass-card"

export function ProvidersScatter() {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    let raf = 0
    const nodes = Array.from(el.querySelectorAll<HTMLElement>("[data-float]"))
    const base = nodes.map(() => ({
      x: (Math.random() - 0.5) * 6,
      y: (Math.random() - 0.5) * 6,
      p: Math.random() * Math.PI * 2,
      s: 0.4 + Math.random() * 0.6,
    }))
    const start = performance.now()
    const tick = (t: number) => {
      const dt = (t - start) / 1000
      nodes.forEach((n, i) => {
        const b = base[i]
        const x = Math.sin(dt * b.s + b.p) * 8 + b.x
        const y = Math.cos(dt * b.s + b.p) * 8 + b.y
        n.style.transform = `translate(${x}px, ${y}px)`
      })
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  const tools = [
    "Kali Linux",
    "Parrot OS",
    "Metasploit",
    "Wireshark",
    "Scapy",
    "Burp Suite",
    "OWASP ZAP",
    "Nmap",
    "Suricata",
    "Snort",
    "Docker",
    "VirtualBox",
    "VMware",
    "Python",
    "SQL",
  ]

  return (
    <section className="space-y-6">
      <header className="text-center">
        <h2 className="text-3xl font-bold">Top tools to unleash potential</h2>
      </header>
      <GlassCard className="relative overflow-hidden p-10">
        <div ref={ref} className="relative grid min-h-[280px] place-items-center">
          <div className="absolute inset-0 -z-10 rounded-xl bg-gradient-to-tr from-white/10 to-transparent blur-3xl" />
          <div className="relative flex flex-wrap items-center justify-center gap-6">
            {tools.map((t) => (
              <div
                key={t}
                data-float
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm backdrop-blur"
              >
                {t}
              </div>
            ))}
          </div>
        </div>
      </GlassCard>
    </section>
  )
}
