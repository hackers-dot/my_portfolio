export function NeonStyles() {
  return (
    <style
      dangerouslySetInnerHTML={{
        __html: `
        .neon-btn-primary {
          background-image: linear-gradient(90deg, #E642F8 0%, #7A5EFF 50%, #00E5FF 100%);
          color: white;
          border: 1px solid rgba(255,255,255,0.18);
          box-shadow: 0 0 24px rgba(122,94,255,0.35);
        }
        .neon-btn-primary:hover { filter: brightness(1.08); }
        .neon-btn-outline {
          background: rgba(255,255,255,0.06);
          color: white;
          border: 1px solid rgba(255,255,255,0.25);
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `,
      }}
    />
  )
}
